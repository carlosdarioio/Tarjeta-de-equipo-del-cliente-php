<?php

// define('LBROOT',getcwd()); // LegoBox Root ... the server root
// include("core/controller/Database.php");

if(!isset($_SESSION["user_id"])) {
$user = $_POST['username'];
$pass = sha1(md5($_POST['password']));

$base = new Database();
$con = $base->connect();
 $sql = "select * from usuarios where (Correo= \"".$user."\" or CodigoDeusuario= \"".$user."\") and password= \"".$pass."\" ";//and is_active=1
//print $sql;
$query = $con->query($sql);
$found = false;
$userid = null;
while($r = $query->fetch_array()){
	$found = true ;
	$userid = $r['id'];
}

if($found==true) {
//	session_start();
//	print $userid;
	$_SESSION['user_id']=$userid ;
//	setcookie('userid',$userid);
//	print $_SESSION['userid'];
	print "Cargando ... $user";
	//Falta if para definir donde direccionara la pag depediendo de quien entre
	//king: 1.- admin,2.- Tecnico, 3.- Mercadeo, 4.- Servicio al cliente, 5. Sup Tecnico --> xd
	$k = UsuarioData::getById($_SESSION["user_id"])->kind;
	$dir="login";
	switch ($k) {
  case 1: $dir="./";break;
  case 2: $dir="./?view=LlamadasDS&TC=".$_SESSION['user_id'];break;
  case 3: $dir="./?view=Contratos";break;
  case 4: $dir="./?view=ListaLlamadasDS";break;
  case 5: $dir="./?view=LlamadasDS";break;
  
  default:
    # code...
	$dir="./?view=login";
    break;
	}

	print "<script>window.location='".$dir."';</script>";//index.php?view=ListaArticulos
}else {
	print "<script>window.location='?view=login&msj=Error';</script>";
}

}else{
		$k = UsuarioData::getById($_SESSION["user_id"])->kind;
	$dir="login";
	switch ($k) {
  case 1: $dir="./";break;
  case 2: $dir="./?view=LlamadasDS&TC=".$_SESSION['user_id'];break;
   case 5: $dir="./?view=LlamadasDS";break;
  case 3: $dir="./?view=Contratos";break;
  case 4: $dir="./?view=ListaLlamadasDS";break;
 
  
  default:
    # code...
	$dir="./?view=login";
    break;
	//print "<script>window.location='index.php?view=ListaArticulos';</script>";
	print "<script>window.location='".$dir."';</script>";//index.php?view=ListaArticulos
	}
}
?>