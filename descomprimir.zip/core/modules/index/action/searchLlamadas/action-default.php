<?php


//Busqueda de tarjetade eqiupo del cliente para asiGNAR LLAMADA
?>

<?php if((isset($_GET["product_name"]) && $_GET["product_name"]!="") || (isset($_GET["product_code"]) && $_GET["product_code"]!="") ):?>
<?php
//search para buscar en ListadellamadasDS
$go = $_GET["go"];
$search  ="";
if($go=="code"){ $search=$_GET["product_code"]; }
else if($go=="name"){ $search=$_GET["product_name"]; }
//se agarra dato de tarjeta de equipo pa verificar que est ectivo
$products = tarjetadeequipodelclienteData::getLike($search);
if(count($products)>0){
	//v1                                        NOSF,Articulo,Descripcion,Codigo,Estado,Calle,NumeroDeCalle,Edificio,CodigoPostal,Cuadra,Ciudad,Pais
	//Tarjeta,Descripcion,Articulo,Estado,Direccion
	?>
	
<h3>Resultados de la Búsqueda: Tarjetas de equipo del cliente</h3>
<div class="box box-primary">
<table class="table table-bordered table-hover">
	<thead>
		<th>id</th>
		<th>Tarjeta</th>		
		<th>Código</th>		
		<th>Estado</th>	
				
		<th></th>
	
	</thead>
	<?php
$products_in_cero=0;
	 foreach($products as $product):
$q= OperationData::getQByStock($product->id,StockData::getPrincipal()->id);
//$q2= tarjetadeequipodelclienteData::getByCodigo($product->Codigo);

	?>
	
		
	
		
		<td><?php echo $product->id; ?></td>
		<td><?php echo $product->Tarjeta; ?></td>
		<td ><?php echo $product->Codigo; ?></td>		
		<td><b><?php echo $product->Estado; ?></b></td>
		
		<td>
		<td>
		<!-- Ver falta                           pones id pa saber de donde jalar los datos en findllamadas-->
<!--<a href="index.php?view=viewLlamadasDS&id=<?php echo $product->id; ?>" class="btn btn-xs"><i class="glyphicon glyphicon-search"></i></a>-->


<a href="./?view=viewtarjetadeequipodelcliente&id=<?php echo $product->id; ?>" class="btn btn-xs"><i class="glyphicon glyphicon-search"></i></a>
	  <!-- crear Solucion-->
	  <!--//EDIT: hay que evaluar si el socio contrato y tarjeta estan activis-->
	  <?php IF($product->Estado!="Inactivo"): ?>
<a href="./?view=newLlamadasDS&id=<?php echo $product->id; ?>" class="btn btn-xs"><i class="glyphicon glyphicon-plus"></i></a>
		<?php endif; ?>
<!--- Edit llamadas lo arias desde la busqueda de llamadas jalando el ide de llamada-->

  </td>
  

		</td>
		<!--
		<td style="width:250px;"><form method="post" action="index.php?view=addtocart">
		<input type="hidden" name="product_id" value="<?php echo $product->id; ?>">

<div class="input-group">
		<input type="hidden" class="form-control" value="1" name="q" placeholder="Cantidad ...">
      <span class="input-group-btn">
		<button type="submit" class="btn btn-primary"><i class="glyphicon glyphicon-plus-sign"></i> Agregar</button>
      </span>
    </div>


		</form></td>-->
	</tr>
	

	<?php endforeach;?>
</table>

</div>
<?php if($products_in_cero>0){ echo "<p class='alert alert-warning'>Se omitieron <b>$products_in_cero tarjetadeequipodelclientes</b> que no tienen existencias en el inventario. <a href='index.php?view=inventary&stock=".StockData::getPrincipal()->id."'>Ir al Inventario</a></p>"; }?>

	<?php
}else{
	echo "<br><p class='alert alert-danger'>No se encontro la tarjeta de equipo especificada</p>";
}
?>
<hr><br>
<?php else:
?>

<?php endif; ?>