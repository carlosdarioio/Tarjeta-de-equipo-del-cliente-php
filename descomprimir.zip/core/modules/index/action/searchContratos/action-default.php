<?php



?>

<?php if((isset($_GET["product_name"]) && $_GET["product_name"]!="") || (isset($_GET["product_code"]) && $_GET["product_code"]!="") ):?>
<?php
$go = $_GET["go"];
$search  ="";
if($go=="code"){ $search=$_GET["product_code"]; }
else if($go=="name"){ $search=$_GET["product_name"]; }
$products = ContratosData::getLike($search);
if(count($products)>0){
	?>
<h3>Resultados de la búsqueda</h3>
<div class="box box-primary">
<table class="table table-bordered table-hover">
	<thead>
		<th>Código</th>
		<th>Nombre</th>		
		<th>Estado</th>
		
		
		<th></th>
	
	</thead>
	<?php
$products_in_cero=0;
	 foreach($products as $product):
$q= OperationData::getQByStock($product->id,StockData::getPrincipal()->id);
	?>
	<!-- foreach Contratos-->
		
	
		
		<td><?php echo $product->Codigo; ?></td>
		<td style="width:80px;"><?php echo $product->Nombre; ?></td>
		
		<td><b><?php echo $product->Estado; ?></b></td>
		 <td>
		
		<!-- Ver falta-->                       <!-- Pasando por la variable id el codigo del cliete q solicita llamada-->
	                                          <!-- cambia los iconos de contratos,llamada y tarjerta de eqiupo-->
<!-- Visualizar todos los datos del cliente-->	
                        <!--//faltaaaa-->										  
<a href="index.php?view=viewContratos&id=<?php echo $product->id; ?>&nombre=<?php echo $product->Nombre; ?>" class="btn btn-xs"><i title="Visualizar Datos del Socio" class="glyphicon glyphicon-search"></i></a>								  
						<!-- Pasando por la variable id el codigo del cliete q solicita newtarjetadeequipodelcliente-->
 <!-- Editar Socio -->
 <?php 
 $k = UsuarioData::getById($_SESSION["user_id"])->kind;
 if( $k==1 or $k==3){ ?>
<a href="index.php?view=editContratos&id=<?php echo $product->id; ?>" class="btn btn-xs btn-warning"><i title="Editar Datos del socio"class="glyphicon glyphicon-pencil"></i></a>
 <!-- Eliminar Socio -->
<a href="index.php?view=delContratos&id=<?php echo $product->id; ?>" class="btn btn-xs btn-danger"><i title="Eliminar Datos del socio"class="fa fa-trash"></i></a>
 <?php }?>

		</td>
	
	</tr>
	
<!-- Fin foreach Contratos-->
	<?php endforeach;?>
</table>

</div>
<?php if($products_in_cero>0){ echo "<p class='alert alert-warning'>Se omitieron <b>$products_in_cero Contratoss</b> que no tienen existencias en el inventario. <a href='index.php?view=inventary&stock=".StockData::getPrincipal()->id."'>Ir al Inventario</a></p>"; }?>
<!-- IMPORTANTE LA LISTA DE CONTRATOS del Socio DEBE DE IR AQUI-->
<!-- Falta aqui mismo foreach Articulos del Socio-->
<!-- Falta aqui mismo foreach Llamadas del Socio-->
<!-- Falta aqui mismo foreach Llamadas del Socio-->
<!-- Falta aqui mismo foreach Contratos del socio del Socio-->
	<?php
}else{
	echo "<br><p class='alert alert-danger'>El Codigo especificado no existe o no tiene Contratos latentes</p>";
}
?>
<hr><br>
<?php else:
?>

<?php endif; ?>