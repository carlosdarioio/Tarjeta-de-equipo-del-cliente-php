<?php
//delusuario
if($_GET["id"]!=$_SESSION["user_id"]){
$r = UsuarioData::getById($_GET["id"]);
$r->del();

Core::alert("Eliminado Exitosamente!");
}else{
Core::alert("No te puedes eliminar a ti mismo!");

}
Core::redir("./?view=usuarios");
?>
