<?php
//Buscando articulos de tarjeta de cliente seleccionada
//Tablas: art_de_tarjeta tarjetadeequipodelcliente   y Producto 

//Si la variable Go no esta vacia
if($_GET["go"]!="" ){
	 //Adquiriendo id de Tarjeta por medio de el nombre de la misma
	$i2=tarjetadeequipodelclienteData::getByTarjeta($_GET["go"])->id;
     //Adquiriendo id de Articulos dentro de la Tarjeta seleccionada
	$i =  art_clientesData::getAllByTarjetaId($i2);
?>
	<label for="inputEmail1" class="col-lg-2 control-label">Articulo</label>
	<select name="product_id" id="product_id" class="form-control">
		<option value="">--  TODOS --</option>
		<?php foreach($i as $p):	?>
		                              <!--Adquiriendo Articulo por medio de idART de la tarjeta -->     
		<option value="<?php echo ProductoData::getById($p->idART)->Articulo;?>" <?php if(isset($_GET["product_id"])){ if($_GET["product_id"]== ProductoData::getById($p->idART)->Articulo){echo " selected";} }?>><?php echo ProductoData::getById($p->idART)->Articulo;?></option>
		<?php  endforeach; ?> 
    </select>
<?php
//Buscando Todos los articulos sin Tarjeta Especificada
}else{
// Adquiriendo Articulos	
$products = ProductoData::getAll();
?>
	<label for="inputEmail1" class="col-lg-2 control-label">Articulo</label>
	<select name="product_id" id="product_id" class="form-control">
		<option value="">--  TODOS --</option>
		<?php foreach($products as $p):?>
		<option value="<?php echo $p->Articulo;?>" ><?php echo $p->Articulo;?></option>
		<?php endforeach; ?>        
	</select>
<?php
}//Fin Else
?>