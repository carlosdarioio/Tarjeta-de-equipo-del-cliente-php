<?php
//art_de_tarjeta

//function atr_de_tar(){
if(isset($_GET["Tarjeta"])){
	
$i =  art_clientesData::getAllByTarjetaId(tarjetadeequipodelclienteData::getByTarjeta($_GET["Tarjeta"])->id);
//$i->select();
//Core::redir("./?view=ps");

?>

<label for="inputEmail1" class="col-lg-2 control-label">Articulo</label>
<select name="product_id" id="product_id" class="form-control">
	<option value="">--  TODOS --</option>
	<?php foreach($i as $p):?>
	<option value="<?php echo $p->Articulo;?>" <?php if(isset($_GET["product_id"])){ if($_GET["product_id"]==$p->Articulo){echo " selected";} }?>><?php echo $p->Articulo;?></option>
	<?php endforeach; ?>                      <?php //if(isset($_GET["Tecnico"])){ if($_GET["Tecnico"]==$p->CodigoDeUsuario){echo "selected";} }?>
</select>


<?php


}
else{


}


//}//fin fun tion



?>