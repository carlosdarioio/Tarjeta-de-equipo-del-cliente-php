<?php



?>

<?php if((isset($_GET["product_name"]) && $_GET["product_name"]!="") || (isset($_GET["product_code"]) && $_GET["product_code"]!="") ):?>
<?php
$go = $_GET["go"];
$search  ="";
if($go=="code"){ $search=$_GET["product_code"]; }
else if($go=="name"){ $search=$_GET["product_name"]; }
//se agarra dato de tarjeta de equipo pa verificar que est ectivo
$products = LlamadasDSData::getLike($search);
if(count($products)>0){
	?>
<h3>Resultados de la Busqueda</h3>
<div class="box box-primary">
<table class="table table-bordered table-hover">
	<thead>

	<!--TipoDeProblema,Descripcion,Codigo,Nombre,Articulo,CodigoDeUsuario,Estado,Telefono,FechaFinal -->
		<th>234Nombre</th>
		<th>Articulo</th>
		<th>Tecnico</th>
		
		<th>Estado</th>
		
		
		<th></th>
	
	</thead>
	<?php
$products_in_cero=0;
	 foreach($products as $product):
$q= OperationData::getQByStock($product->id,StockData::getPrincipal()->id);
	?>
	
		
	
		
		<td><?php echo $product->Nombre; ?></td>
		<td><?php echo $product->Articulo; ?></td>
		<td style="width:80px;"><?php echo $product->CodigoDeUsuario; ?></td>
		
		<td><b>$<?php echo $product->Estado; ?></b></td>
		
		<td>
		<!-- Ver falta-->
<a href="index.php?view=newLlamadasDS&id=<?php echo $product->Codigo; ?>" class="btn btn-xs"><i class="glyphicon glyphicon-search"></i></a>
	  <!-- crear Solucion-->
<a href="index.php?view=newLlamadasDS&id=<?php echo $product->Codigo; ?>" class="btn btn-xs"><i class="glyphicon glyphicon-plus"></i></a>
<a href="index.php?view=editLlamadasDS&id=<?php echo $product->Codigo; ?>" class="btn btn-xs btn-warning"><i class="glyphicon glyphicon-pencil"></i></a>
<a href="index.php?view=delLlamadasDS&id=<?php echo $product->Codigo; ?>" class="btn btn-xs btn-danger"><i class="fa fa-trash"></i></a>
  </td>

		
		<!--
		<td style="width:250px;"><form method="post" action="index.php?view=addtocart">
		<input type="hidden" name="product_id" value="<?php echo $product->id; ?>">

<div class="input-group">
		<input type="hidden" class="form-control" value="1" name="q" placeholder="Cantidad ...">
      <span class="input-group-btn">
		<button type="submit" class="btn btn-primary"><i class="glyphicon glyphicon-plus-sign"></i> Agregar</button>
      </span>
    </div>


		</form></td>-->
	</tr>
	

	<?php endforeach;?>
</table>

</div>
<?php if($products_in_cero>0){ echo "<p class='alert alert-warning'>Se omitieron <b>$products_in_cero LlamadasDSs</b> que no tienen existencias en el inventario. <a href='index.php?view=inventary&stock=".StockData::getPrincipal()->id."'>Ir al Inventario</a></p>"; }?>

	<?php
}else{
	echo "<br><p class='alert alert-danger'>No se encontraron Registros de Llamadas</p>";
}
?>
<hr><br>
<?php else:
?>

<?php endif; ?>