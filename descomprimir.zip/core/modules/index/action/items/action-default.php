<?php
if(isset($_GET["opt"]) && $_GET["opt"]=="add"){
$grade = new ItemData();
$grade->name = $_POST["name"];
$grade->add();
Core::redir("./?view=items&opt=all");
}
else if(isset($_GET["opt"]) && $_GET["opt"]=="update"){
if(count($_POST)>0){
	$user = ItemData::getById($_POST["user_id"]);
	$user->name = $_POST["name"];
	$user->update();
Core::redir("./?view=items&opt=all");
}
}
else if(isset($_GET["opt"]) && $_GET["opt"]=="del"){
$category = ItemData::getById($_GET["id"]);
$category->del();
Core::redir("./?view=items&opt=all");

}






?>