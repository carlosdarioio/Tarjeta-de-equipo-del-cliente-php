<?php
//Incluyendo Controladores
$show_errors = true;
if($show_errors){
error_reporting(E_ALL);
ini_set('display_errors', TRUE);
ini_set('display_startup_errors', TRUE);
}

include "controller/Core.php";
include "controller/View.php";
include "controller/Module.php";
include "controller/Database.php";
include "controller/Executor.php";


include "controller/forms/lbForm.php";
include "controller/forms/lbInputText.php";
include "controller/forms/lbInputPassword.php";
include "controller/forms/lbValidator.php";


include "controller/Model.php";
include "controller/Bootload.php";
include "controller/Action.php";


include "controller/Request.php";



include "controller/Get.php";
include "controller/Post.php";
include "controller/Cookie.php";
include "controller/Session.php";
include "controller/Lb.php";


include "controller/Form.php";
include "controller/class.upload.php";


?>